# Recognition Result — Design Package Closure V1

Status: **PASS — DESIGN FROZEN**

## Purpose

Close the existing Recognition Result 3+2 Hi-Fi states into one implementation-ready design package without redesigning the approved screens.

This closure covers:

- five state definitions
- authority order
- behavior
- visual hierarchy
- copy roles
- CTA semantics
- transition/motion
- accessibility / compact-height behavior
- shared-component use
- variable-aspect-ratio Hero media placement
- runtime alignment review
- acceptance criteria

It does not change:
- detector behavior
- crop behavior
- classifier behavior
- confidence thresholds
- Recognition Processing V1.1 timing
- the five approved Frozen PNGs

## Closure result

| Area | Result |
| --- | --- |
| 5 Frozen state references | PASS |
| Authority order | PASS |
| State matrix | PASS |
| Behavior contract | PASS |
| Visual contract | PASS |
| CTA contract | PASS |
| Result transition | PASS |
| Accessibility / compact-height rule | PASS |
| Shared component rule | PASS |
| Hero Media Contract V1 | PASS — FROZEN |
| Layout Geometry V1 | PASS — FROZEN |
| Component Map V1 | PASS — FROZEN |
| Metadata Input Contract V1 | PASS — FROZEN |
| Metadata Edit Flow V1 | PASS — FROZEN |
| Candidate Card V1 | PASS — FROZEN |
| Visual Acceptance Map V1 | PASS — FROZEN |
| Asset Manifest / Result | PASS — FROZEN |
| Implementation readiness | **PASS — IMPLEMENTATION READY** |
| Acceptance criteria | PASS |
| Runtime consistency | NEEDS IMPLEMENTATION CLOSURE |

## Frozen states

3 result states:
1. High
2. Medium
3. Low

2 recovery states:
4. No Fish
5. Image Quality

Technical failure is a runtime-safe fallback only and is not promoted into a sixth frozen Result design.

## Content-edit authority index

RR06 · 内容修改 links the already-frozen Species Selector V1 and Metadata Edit Flow V1 visual/specification authorities. The index does not combine their contracts, alter their individual boundaries, or expand the 3+2 product state model. Canonical files remain at their existing paths; see `06_content_edit/README.md`.

## Explicit authority decisions

1. The five state PNGs 05–09 are the final authority for state-specific composition, hierarchy and visible copy.
2. `recognition_result_v1.png` remains the system-level Result visual-language reference.
3. If the system reference and a state PNG differ, the state PNG wins for that state.
4. The user's real captured photo is runtime media and must never be replaced by a static design asset.
5. Dynamic user-photo placement is frozen by `media/Recognition_Result_Hero_Media_Contract_V1.md`; High/Medium/Low use fish-aware subject protection, while No Fish/Image Quality use evidence-preserving Fit.
6. Result screens do not inherit Processing AI filaments, contour, halo or HUD-like effects.
7. Shared P0 actions/navigation must be reused; page-private button systems are not authorized.
8. Low confidence is a recoverable record state, not a forced-failure state.
9. No Fish and Image Quality are recovery screens and do not create FishRecords.

## Known implementation boundary

The current Android runtime does not fully match the closed design package.

The authoritative gap list is:

`review/Recognition_Result_Runtime_Alignment_Review_V1.md`

Design closure itself does not claim Runtime PASS.

## Freeze definition

Any change to:
- 3+2 state information architecture
- CTA meaning
- low-confidence save policy
- candidate-confirmation model
- state-level Frozen composition
- Result-to-memory flow

requires a versioned Result package revision.


## Implementation readiness declaration

The Design Package is now **IMPLEMENTATION READY**.

Work/frontend may make implementation choices only where explicitly left to platform/runtime by a frozen contract. It must not make independent visual-design decisions for:
- page geometry;
- adaptive width/height behavior;
- component selection;
- Result metadata inputs;
- Result metadata lightweight modification / Bottom Sheet flow;
- Medium candidate-card visuals/states;
- dynamic Hero media placement;
- visual acceptance tolerances;
- Result asset/component sourcing.

Runtime parity remains `NEEDS_CLOSURE` until implementation and evidence pass.
